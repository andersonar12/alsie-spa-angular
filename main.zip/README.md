# AlsieClient

This project was generated with [Angular CLI](https://github.com/angular/angular-cli) version 11.1.4.

## Install dependencies

Angular CLI
`npm install @angular/cli --global`

http-server
`npm install http-server --global`

Install other dependencies
`npm install`

## Development server

Run `ng serve` for a dev server. Navigate to `http://localhost:4210/`. The app will automatically reload if you change any of the source files.

## Development run server for PWA

First build the project `ng build --prod`

Run `http-server -p 8091 -c-1 dist/app-client` for a dev server for PWA. Navigate to `http://127.0.0.1:8091/`.

## Code scaffolding

Run `ng generate component component-name` to generate a new component. You can also use `ng generate directive|pipe|service|class|guard|interface|enum|module`.

## Build

Run `ng build` to build the project. The build artifacts will be stored in the `dist/` directory. Use the `--prod` flag for a production build.

## Running unit tests

Run `ng test` to execute the unit tests via [Karma](https://karma-runner.github.io).

## Running end-to-end tests

Run `ng e2e` to execute the end-to-end tests via [Protractor](http://www.protractortest.org/).

## Further help

To get more help on the Angular CLI use `ng help` or go check out the [Angular CLI Overview and Command Reference](https://angular.io/cli) page.
